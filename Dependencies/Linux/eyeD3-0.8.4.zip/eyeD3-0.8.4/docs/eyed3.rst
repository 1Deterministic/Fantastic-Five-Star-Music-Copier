eyed3 package
=============

Subpackages
-----------

.. toctree::

    eyed3.id3
    eyed3.mp3
    eyed3.plugins
    eyed3.utils

Submodules
----------

eyed3\.compat module
--------------------

.. automodule:: eyed3.compat
    :members:
    :undoc-members:
    :show-inheritance:

eyed3\.core module
------------------

.. automodule:: eyed3.core
    :members:
    :undoc-members:
    :show-inheritance:

eyed3\.main module
------------------

.. automodule:: eyed3.main
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: eyed3
    :members:
    :undoc-members:
    :show-inheritance:
