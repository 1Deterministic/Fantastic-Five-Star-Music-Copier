eyed3.mp3 package
=================

Submodules
----------

eyed3.mp3.headers module
------------------------

.. automodule:: eyed3.mp3.headers
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: eyed3.mp3
    :members:
    :undoc-members:
    :show-inheritance:
