eyed3.plugins package
=====================

Submodules
----------

eyed3.plugins.art module
------------------------

.. automodule:: eyed3.plugins.art
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.classic module
----------------------------

.. automodule:: eyed3.plugins.classic
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.display module
----------------------------

.. automodule:: eyed3.plugins.display
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.fixup module
--------------------------

.. automodule:: eyed3.plugins.fixup
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.genres module
---------------------------

.. automodule:: eyed3.plugins.genres
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.itunes module
---------------------------

.. automodule:: eyed3.plugins.itunes
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.lameinfo module
-----------------------------

.. automodule:: eyed3.plugins.lameinfo
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.nfo module
------------------------

.. automodule:: eyed3.plugins.nfo
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.pymod module
--------------------------

.. automodule:: eyed3.plugins.pymod
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.stats module
--------------------------

.. automodule:: eyed3.plugins.stats
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.plugins.xep_118 module
----------------------------

.. automodule:: eyed3.plugins.xep_118
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: eyed3.plugins
    :members:
    :undoc-members:
    :show-inheritance:
