eyed3.id3 package
=================

Submodules
----------

eyed3.id3.apple module
----------------------

.. automodule:: eyed3.id3.apple
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.id3.frames module
-----------------------

.. automodule:: eyed3.id3.frames
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.id3.headers module
------------------------

.. automodule:: eyed3.id3.headers
    :members:
    :undoc-members:
    :show-inheritance:

eyed3.id3.tag module
--------------------

.. automodule:: eyed3.id3.tag
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: eyed3.id3
    :members:
    :undoc-members:
    :show-inheritance:
